SELECT user_id, book_id
FROM status;
