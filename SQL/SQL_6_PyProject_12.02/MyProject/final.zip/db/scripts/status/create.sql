INSERT INTO status(book_id, visitor_id)
VALUES (?, ?)