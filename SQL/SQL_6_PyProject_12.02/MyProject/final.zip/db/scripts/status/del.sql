DELETE FROM status
WHERE status_id = ?;