DELETE FROM visitors
WHERE visitor_id = ?;