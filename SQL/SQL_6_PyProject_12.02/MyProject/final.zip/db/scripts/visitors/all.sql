SELECT name, surname, middle_name, library_card_id, adress
from visitors;