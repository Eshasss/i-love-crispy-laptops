INSERT INTO visitors(name, surname, middle_name, library_card_id, adress)
VALUES (?, ?, ?, ?, ?)