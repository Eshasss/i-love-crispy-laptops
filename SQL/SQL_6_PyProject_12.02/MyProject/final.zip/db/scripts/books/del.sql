DELETE FROM status
WHERE book_id = ?;