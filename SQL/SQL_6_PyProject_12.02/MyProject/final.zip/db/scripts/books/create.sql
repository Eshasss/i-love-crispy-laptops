INSERT INTO books (name, author, year, edition, bookcase_id, bookshelf_id)
VALUES (?,?,?,?,?, ?)