SELECT name
FROM books
WHERE author  = ?;