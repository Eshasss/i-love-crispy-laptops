SELECT name
FROM books
WHERE bookcase_id = ?, bookshelf_id = ?;