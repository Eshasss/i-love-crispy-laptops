SELECT name, author, year, edition, bookcase_id, bookshelf_id
FROM books; 