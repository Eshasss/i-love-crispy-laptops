SELECT name
FROM books
WHERE year = ?;